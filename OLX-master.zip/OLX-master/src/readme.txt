This is the src folder of the project that consists of all java files. (BackEnd)
